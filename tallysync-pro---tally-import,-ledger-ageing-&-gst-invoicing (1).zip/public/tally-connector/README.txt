TallySync Pro connector
Run start-connector.bat on the computer where TallyPrime is installed.
Connector port: 9101. TallyPrime port: 9000.
Then enter that computer's reachable IP/URL in Connect Tally on the website.
