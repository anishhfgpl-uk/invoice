(()=>{
function addDownload(){
  if(document.getElementById('anish-connector-download')) return;
  const a=document.createElement('a');
  a.id='anish-connector-download';
  a.href='https://github.com/anishhfgpl-uk/invoice/raw/refs/heads/main/tally-connector/tally-connector.mjs';
  a.download='anish-tally-connector.mjs';
  a.target='_blank';
  a.rel='noopener';
  a.textContent='⬇ Download Tally Connector';
  a.style.cssText='position:fixed;right:24px;bottom:78px;z-index:99999;display:block;padding:12px 18px;border:0;border-radius:12px;background:#2563eb;color:#fff;font:800 14px Arial,sans-serif;text-decoration:none;box-shadow:0 8px 25px #0003';
  document.body.appendChild(a);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',addDownload);else addDownload();
})();
