TallySync Pro - Office Connector
1. Install Node.js LTS on the computer where TallyPrime is installed.
2. Make sure TallyPrime HTTP Server is enabled on port 9000.
3. Run start-connector.bat.
4. For remote office access, enter the Office Code in the website.
5. The Tally computer must remain ON with TallyPrime and connector running.
Direct LAN mode can also use http://COMPUTER-IP:9101.
